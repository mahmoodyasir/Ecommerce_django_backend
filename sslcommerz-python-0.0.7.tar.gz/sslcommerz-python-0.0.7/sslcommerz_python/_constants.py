SSLCZ_SESSION_API = 'sslcommerz.com/gwprocess/v4/api.php'
SSLCZ_VALIDATION_API = 'sslcommerz.com/validator/api/validationserverAPI.php'
